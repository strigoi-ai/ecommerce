<?php
	/* Template Name: ABOUT */

	get_header();
?>
<!DOCTYPE html>
<html lang="en">
<head>

<div class="container">
  <div class="jumbotron">
    <h1 style="color: yellow; font-family: Bernard MT Condensed;"> About Ali's Pup & Drag</h1>      
    <p style="color: yellow; font-family: Bernard MT Condensed; font-size: 50px; ">We started opening this business in 2020
we provide our costumer a best vape experience
that they will enjoy.
Even if we just a new opened business many
costumer is happy or satisfied in our service
and product.</p>
	<p style="color: yellow; font-family: Bernard MT Condensed; font-size: 50px; text-align: center; ">Thank You for Visiting</p>
  </div>   
</div>